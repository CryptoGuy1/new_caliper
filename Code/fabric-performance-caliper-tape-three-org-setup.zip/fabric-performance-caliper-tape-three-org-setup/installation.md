Here’s a beautifully formatted README markdown file based on your provided content. This version organizes the information into clear sections, uses headings, lists, and code blocks for better readability.
text
# Hyperledger Fabric Installation Guide

## Prerequisites

Before you begin, ensure you have the following software installed on your system:

1. **Operating Systems**: 
   - Ubuntu Linux Jammy 22.04 (LTS)
   - macOS

2. **Required Tools**:
   - **cURL**: The latest version
   - **Git**
   - **Docker Engine**: Version 17.06.2-ce or greater
   - **Docker Compose**: Version 1.14 or greater
   - **Go**: Version 1.13.x
   - **Node.js**: Version 10.21 (Node.js version 10 is supported from 10.15.3 and higher)
   - **npm**: Version 6.14.4
   - **Python**: 2.7.x

## Installation Steps

### 
1. Install cURL

```bash
sudo apt-get install curl
```
2. Update Package List
```bash
sudo apt update
```

3. Node Installation using NVM
```bash
curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.3/install.sh | bash

source ~/.bashrc

nvm list-remote

nvm install 18

nvm list
```

4. Install npm
```bash
sudo apt-get install npm
```
5. Install Python
```bash
sudo apt-get install python
```
6. Install and Upgrade Docker & Docker Compose
Install Docker
```bash
# Add Docker's official GPG key:
sudo apt-get update
sudo apt-get install ca-certificates curl
sudo install -m 0755 -d /etc/apt/keyrings
sudo curl -fsSL https://download.docker.com/linux/ubuntu/gpg -o /etc/apt/keyrings/docker.asc
sudo chmod a+r /etc/apt/keyrings/docker.asc

# Add the repository to Apt sources:
echo \
  "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.asc] https://download.docker.com/linux/ubuntu \
  $(. /etc/os-release && echo "$VERSION_CODENAME") stable" | \
  sudo tee /etc/apt/sources.list.d/docker.list > /dev/null
sudo apt-get update

Install the Docker packages - (This was the latest 5:27.1.1-1~ubuntu.24.04~noble)
sudo apt-get install docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin

```

7. Try to run 
```bash
docker run hello-world
```
8.If you are getting permission error, run below command
```bash
sudo usermod -aG docker $USER && newgrp docker
```
9. Validate if docker is working fine using following command
```bash
docker run hello-world

# you will be able to see   ---> Hello from Docker!

```


7. Docker compose - Install using the repository
```bash
sudo apt-get update
sudo apt-get install docker-compose-plugin
```


7. Upgrade Packages
```bash
sudo apt-get upgrade
```

10. Verify All Versions
```bash
curl -V
npm -v
docker version
docker-compose version
go version
python -V
node -v
```

Install Fabric Samples, Binaries & Docker Images
1. Install Latest Images
```bash
curl -sSLO https://raw.githubusercontent.com/hyperledger/fabric/main/scripts/install-fabric.sh && chmod +x install-fabric.sh
./install-fabric.sh -h
./install-fabric.sh --fabric-version 2.5.5 -c 1.5.7
export PATH=$PATH:/home/ubuntu/fabric-samples/bin

```

Run Test Network in Fabric Sample
```bash
./network.sh createChannel -ca -s couchdb
./network.sh deployCC
```


Configure Remote SSH Extension in VS Code
Install the Remote - SSH extension by Microsoft.
To connect, use:
```bash
ssh ubuntu@<public IP>
```


Install Go Lang
```bash

sudo snap install go --classic

```