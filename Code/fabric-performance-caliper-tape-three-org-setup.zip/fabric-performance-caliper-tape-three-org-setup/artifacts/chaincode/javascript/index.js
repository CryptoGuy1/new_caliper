'use strict';

const performance = require('./lib/Performance');

module.exports.Performance = performance;
module.exports.contracts = [performance];
