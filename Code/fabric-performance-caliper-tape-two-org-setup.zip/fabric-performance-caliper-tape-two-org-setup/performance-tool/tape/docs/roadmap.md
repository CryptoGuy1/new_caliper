# roadmap
Ref to https://www.hyperledger.org/learn/publications/blockchain-performance-metrics

## 0.2.x
- Support traffic with constant rate for durability test (#45)
- Support Test peer/orderer **separately** / support query (#56)
- ~~Report Time when response received – submit time latency for tx (#94)~~
- Support input arguments templating (#109)

## 0.3.x
- Report Time when response received – submit time latency for tx (#94）
- Supports success rate and further enhancment for tx recording(#14)
- SDK adaptor